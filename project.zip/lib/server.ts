import app from "./app";
const PORT = 7000;

app.listen(PORT, () => {
    console.log('Express server listening on port ' + PORT);
})